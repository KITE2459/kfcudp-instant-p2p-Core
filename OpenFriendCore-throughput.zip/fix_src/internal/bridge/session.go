package bridge

import (
	"context"
	"errors"
	"log/slog"
	"sync"
	"time"

	"github.com/pion/webrtc/v4"
)

type Role int

const (
	RoleAcceptor Role = iota
	RoleInitiator
)

type Session struct {
	SessionID string
	Role      Role

	pc     *webrtc.PeerConnection
	dc     *webrtc.DataChannel
	logger *slog.Logger

	mu        sync.Mutex
	queuedICE []webrtc.ICECandidateInit
	remoteSet bool

	onLocalICE func(*webrtc.ICECandidate)
	onData     func([]byte)
	onClose    func()

	dcOpenCh   chan struct{}
	dcOpenOnce sync.Once

	// DataChannel 수신 큐 - pion goroutine 블로킹 방지
	recvCh     chan *recvBuf
	recvOnce   sync.Once

	// DataChannel 흐름 제어 - backpressure
	pauseMu    sync.Mutex
	sendPaused bool
	resumeCh   chan struct{}
}

func NewSession(api *webrtc.API, cfg webrtc.Configuration, role Role, sessionID string, _ [16]byte,
	onLocalICE func(*webrtc.ICECandidate),
	onData func([]byte),
	onClose func(),
	logger *slog.Logger) (*Session, error) {
	if logger == nil {
		logger = slog.Default()
	}
	pc, err := api.NewPeerConnection(cfg)
	if err != nil {
		return nil, err
	}
	s := &Session{
		SessionID:  sessionID,
		Role:       role,
		pc:         pc,
		logger:     logger,
		onLocalICE: onLocalICE,
		onData:     onData,
		onClose:    onClose,
		dcOpenCh:   make(chan struct{}),
		// 16명 × 세션당 동시 수신 패킷을 흡수할 수 있도록 확대
		recvCh:     make(chan *recvBuf, 16384),
		resumeCh:   make(chan struct{}),
	}
	// pion OnMessage 콜백과 완전히 분리된 수신 처리 루프
	go s.recvLoop()
	pc.OnICECandidate(func(c *webrtc.ICECandidate) {
		if c == nil || s.onLocalICE == nil {
			return
		}
		s.onLocalICE(c)
	})
	pc.OnConnectionStateChange(func(state webrtc.PeerConnectionState) {
		s.logger.Debug("PeerConnection state", "state", state)
		if state == webrtc.PeerConnectionStateFailed {
			if s.onClose != nil {
				s.onClose()
			}
		}
	})

	if role == RoleAcceptor {
		pc.OnDataChannel(s.attachDataChannel)
	}
	return s, nil
}

const (
	// 모장 MC와 동일한 임계값
	dcBufferLow  = 512 * 1024       // 512KB - 이 이하로 내려가면 Send 재개
	dcBufferHigh = 4 * 1024 * 1024  // 4MB  - 이 이상이면 Send 대기
)

// recvBuf - 수신 버퍼 하나
type recvBuf struct {
	data [65536]byte
	len  int
}

// recvBufPool - 미리 할당된 고정 버퍼 풀
// make([]byte, n)을 반복하지 않아 GC 압박 없음
type recvBufPoolT struct {
	ch chan *recvBuf
}

// globalRecvPool - 모든 Session이 공유하는 수신 버퍼 풀
// 16명 동시 세션 × burst를 커버하도록 8192로 확대
var globalRecvPool = newRecvBufPool(8192)

func newRecvBufPool(size int) *recvBufPoolT {
	ch := make(chan *recvBuf, size)
	for i := 0; i < size; i++ {
		ch <- &recvBuf{}
	}
	return &recvBufPoolT{ch: ch}
}

func (p *recvBufPoolT) get() *recvBuf {
	select {
	case b := <-p.ch:
		return b
	default:
		// 풀이 고갈되면 새로 할당 (예외 상황)
		return &recvBuf{}
	}
}

func (p *recvBufPoolT) put(b *recvBuf) {
	select {
	case p.ch <- b:
	default:
		// 풀이 가득 차면 그냥 버림 (GC가 수집)
	}
}

func (s *Session) attachDataChannel(dc *webrtc.DataChannel) {
	s.logger.Info("[rtc] DataChannel attached", "label", dc.Label())
	s.mu.Lock()
	s.dc = dc
	s.mu.Unlock()

	// SCTP 송신 버퍼 흐름 제어
	// OnBufferedAmountLow는 pion 내부 goroutine에서 호출되므로
	// pauseMu를 mu와 분리해서 데드락 방지
	dc.SetBufferedAmountLowThreshold(dcBufferLow)
	dc.OnBufferedAmountLow(func() {
		s.pauseMu.Lock()
		if s.sendPaused {
			s.sendPaused = false
			// resumeCh를 교체 후 닫아서 대기 중인 Send()를 깨움
			ch := s.resumeCh
			s.resumeCh = make(chan struct{})
			close(ch)
		}
		s.pauseMu.Unlock()
	})

	dc.OnOpen(func() {
		s.dcOpenOnce.Do(func() { close(s.dcOpenCh) })
	})
	dc.OnClose(func() {
		if s.onClose != nil {
			s.onClose()
		}
	})
	dc.OnMessage(func(msg webrtc.DataChannelMessage) {
		b := globalRecvPool.get()
		b.len = copy(b.data[:], msg.Data)
		s.recvCh <- b
	})
	if dc.ReadyState() == webrtc.DataChannelStateOpen {
		s.dcOpenOnce.Do(func() { close(s.dcOpenCh) })
	}
}

func (s *Session) HandleOffer(offerSDP string) (string, error) {
	err := s.pc.SetRemoteDescription(webrtc.SessionDescription{
		Type: webrtc.SDPTypeOffer,
		SDP:  offerSDP,
	})
	if err != nil {
		return "", err
	}
	s.mu.Lock()
	s.remoteSet = true
	queued := s.queuedICE
	s.queuedICE = nil
	s.mu.Unlock()
	for _, c := range queued {
		if err := s.pc.AddICECandidate(c); err != nil {
			s.logger.Warn("Failed to add queued ICE", "err", err)
		}
	}

	answer, err := s.pc.CreateAnswer(nil)
	if err != nil {
		return "", err
	}
	if err := s.pc.SetLocalDescription(answer); err != nil {
		return "", err
	}
	return answer.SDP, nil
}

func (s *Session) CreateOffer() (string, error) {
	if s.Role != RoleInitiator {
		return "", errors.New("CreateOffer only valid for initiator")
	}
	ordered := true
	dc, err := s.pc.CreateDataChannel("minecraft", &webrtc.DataChannelInit{
		Ordered: &ordered,
	})
	if err != nil {
		return "", err
	}
	s.attachDataChannel(dc)

	offer, err := s.pc.CreateOffer(nil)
	if err != nil {
		return "", err
	}
	if err := s.pc.SetLocalDescription(offer); err != nil {
		return "", err
	}
	return offer.SDP, nil
}

func (s *Session) HandleAnswer(answerSDP string) error {
	if s.Role != RoleInitiator {
		return errors.New("HandleAnswer only valid for initiator")
	}
	err := s.pc.SetRemoteDescription(webrtc.SessionDescription{
		Type: webrtc.SDPTypeAnswer,
		SDP:  answerSDP,
	})
	if err != nil {
		return err
	}
	s.mu.Lock()
	s.remoteSet = true
	queued := s.queuedICE
	s.queuedICE = nil
	s.mu.Unlock()
	for _, c := range queued {
		if err := s.pc.AddICECandidate(c); err != nil {
			s.logger.Warn("Failed to add queued ICE", "err", err)
		}
	}
	return nil
}

func (s *Session) AddRemoteICE(init webrtc.ICECandidateInit) {
	s.mu.Lock()
	if !s.remoteSet {
		s.queuedICE = append(s.queuedICE, init)
		s.mu.Unlock()
		return
	}
	s.mu.Unlock()
	if err := s.pc.AddICECandidate(init); err != nil {
		s.logger.Warn("Failed to add ICE", "err", err)
	}
}

func (s *Session) WaitDataChannelOpen(ctx context.Context, timeout time.Duration) (*webrtc.DataChannel, error) {
	tctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	select {
	case <-s.dcOpenCh:
		s.mu.Lock()
		dc := s.dc
		s.mu.Unlock()
		if dc == nil {
			return nil, errors.New("data channel was reset")
		}
		return dc, nil
	case <-tctx.Done():
		return nil, tctx.Err()
	}
}

// recvLoop - recvCh에서 꺼내서 onData 호출.
// pion OnMessage goroutine과 완전히 분리되어 블로킹 없이 수신 처리.
func (s *Session) recvLoop() {
	for b := range s.recvCh {
		if s.onData != nil {
			s.onData(b.data[:b.len])
		}
		globalRecvPool.put(b)
	}
}

// Send - DataChannel로 데이터 전송.
// SCTP 버퍼가 dcBufferHigh를 초과하면 OnBufferedAmountLow 콜백까지 블로킹.
// pauseMu와 mu를 분리해서 OnBufferedAmountLow 콜백과의 데드락 방지.
// sendPaused 세팅과 resumeCh 캡처를 같은 락 안에서 처리해서 레이스 컨디션 방지.
// 최대 5초 타임아웃: DataChannel이 갑자기 닫혀도 goroutine이 영구 블로킹되지 않음.
func (s *Session) Send(data []byte) error {
	s.mu.Lock()
	dc := s.dc
	s.mu.Unlock()
	if dc == nil || dc.ReadyState() != webrtc.DataChannelStateOpen {
		return errors.New("data channel not open")
	}

	// 버퍼 초과 시 콜백 신호까지 대기 (최대 5초)
	for dc.BufferedAmount() > dcBufferHigh {
		s.pauseMu.Lock()
		s.sendPaused = true
		resumeCh := s.resumeCh
		s.pauseMu.Unlock()

		select {
		case <-resumeCh:
		case <-time.After(5 * time.Second):
			s.logger.Warn("[rtc] Send backpressure timeout — DataChannel may be stalled")
			return errors.New("send backpressure timeout")
		}

		if dc.ReadyState() != webrtc.DataChannelStateOpen {
			return errors.New("data channel closed while waiting")
		}
	}

	return dc.Send(data)
}

func (s *Session) Close() {
	s.mu.Lock()
	dc := s.dc
	pc := s.pc
	s.dc = nil
	s.pc = nil
	s.mu.Unlock()
	if dc != nil {
		_ = dc.Close()
	}
	if pc != nil {
		_ = pc.Close()
	}
	// recvLoop 종료
	s.recvOnce.Do(func() { close(s.recvCh) })
}