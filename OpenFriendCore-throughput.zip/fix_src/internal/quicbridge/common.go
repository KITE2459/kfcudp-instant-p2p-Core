package quicbridge

import (
	"io"
	"net"
	"sync"
	"time"

	"github.com/quic-go/quic-go"
)

const (
	copyBufSize    = 512 * 1024 // 512KB
	tcpSockBufSize = 256 * 1024 // 256KB

	quicStreamWindow = 32 * 1024 * 1024
	quicConnWindow   = 256 * 1024 * 1024
)

var quicBackendServerConfig = &quic.Config{
	MaxIncomingStreams:              4096,
	KeepAlivePeriod:                5 * time.Second,
	MaxIdleTimeout:                 60 * time.Second,
	InitialStreamReceiveWindow:     quicStreamWindow,
	MaxStreamReceiveWindow:         quicStreamWindow,
	InitialConnectionReceiveWindow: quicConnWindow,
	MaxConnectionReceiveWindow:     quicConnWindow,
}

var quicClientConfig = &quic.Config{
	KeepAlivePeriod:                5 * time.Second,
	MaxIdleTimeout:                 60 * time.Second,
	InitialStreamReceiveWindow:     quicStreamWindow,
	MaxStreamReceiveWindow:         quicStreamWindow,
	InitialConnectionReceiveWindow: quicConnWindow,
	MaxConnectionReceiveWindow:     quicConnWindow,
}

type quicStreamConn struct {
	*quic.Stream
	conn *quic.Conn
}

func wrapQuicStream(s *quic.Stream, c *quic.Conn) net.Conn {
	return &quicStreamConn{Stream: s, conn: c}
}

func (c *quicStreamConn) LocalAddr() net.Addr {
	if c.conn != nil {
		return c.conn.LocalAddr()
	}
	return &net.TCPAddr{}
}

func (c *quicStreamConn) RemoteAddr() net.Addr {
	if c.conn != nil {
		return c.conn.RemoteAddr()
	}
	return &net.TCPAddr{}
}

func (c *quicStreamConn) Close() error {
	c.Stream.CancelRead(0)
	return c.Stream.Close()
}

func (c *quicStreamConn) SetDeadline(t time.Time) error      { return c.Stream.SetDeadline(t) }
func (c *quicStreamConn) SetReadDeadline(t time.Time) error  { return c.Stream.SetReadDeadline(t) }
func (c *quicStreamConn) SetWriteDeadline(t time.Time) error { return c.Stream.SetWriteDeadline(t) }

func joinConns(a, b net.Conn) {
	var wg sync.WaitGroup
	wg.Add(2)
	go func() {
		defer wg.Done()
		buf := make([]byte, copyBufSize)
		_, _ = io.CopyBuffer(a, b, buf)
		a.Close()
		b.Close()
	}()
	go func() {
		defer wg.Done()
		buf := make([]byte, copyBufSize)
		_, _ = io.CopyBuffer(b, a, buf)
		b.Close()
		a.Close()
	}()
	wg.Wait()
}

func joinConnGeneric(quicConn net.Conn, tcpConn net.Conn) {
	var wg sync.WaitGroup
	wg.Add(2)
	go func() {
		defer wg.Done()
		buf := make([]byte, copyBufSize)
		_, _ = io.CopyBuffer(quicConn, tcpConn, buf)
		quicConn.Close()
		if tc, ok := tcpConn.(*net.TCPConn); ok {
			tc.CloseRead()
		}
	}()
	go func() {
		defer wg.Done()
		buf := make([]byte, copyBufSize)
		_, _ = io.CopyBuffer(tcpConn, quicConn, buf)
		if tc, ok := tcpConn.(*net.TCPConn); ok {
			tc.CloseWrite()
		} else {
			tcpConn.Close()
		}
	}()
	wg.Wait()
	quicConn.Close()
	tcpConn.Close()
}