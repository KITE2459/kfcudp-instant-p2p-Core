package quicbridge

import (
	"context"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net"

	"github.com/quic-go/quic-go"
)

func Host(ctx context.Context, listenAddr, target string, logger *slog.Logger) error {
	tlsCfg, err := ServerTLSConfig()
	if err != nil {
		return fmt.Errorf("TLS config: %w", err)
	}

	ln, err := quic.ListenAddr(listenAddr, tlsCfg, quicBackendServerConfig)
	if err != nil {
		return fmt.Errorf("QUIC listen: %w", err)
	}
	defer ln.Close()

	logger.Info("[quic-host] listening", "addr", listenAddr, "target", target)
	fmt.Printf("QUIC Host: listen=%s target=%s\n", listenAddr, target)

	for {
		conn, err := ln.Accept(ctx)
		if err != nil {
			if ctx.Err() != nil {
				return nil
			}
			logger.Warn("[quic-host] accept failed", "err", err)
			continue
		}
		go handleConn(ctx, conn, target, logger)
	}
}

func handleConn(ctx context.Context, conn *quic.Conn, target string, logger *slog.Logger) {
	remote := conn.RemoteAddr().String()
	logger.Info("[quic-host] client connected", "remote", remote)
	defer conn.CloseWithError(0, "bye")

	for {
		stream, err := conn.AcceptStream(ctx)
		if err != nil {
			if !errors.Is(err, io.EOF) {
				logger.Debug("[quic-host] stream accept ended", "err", err)
			}
			return
		}
		go bridgeStream(stream, conn, target, remote, logger)
	}
}

func bridgeStream(stream *quic.Stream, conn *quic.Conn, target, remote string, logger *slog.Logger) {
	quicConn := wrapQuicStream(stream, conn)

	tcp, err := net.Dial("tcp", target)
	if err != nil {
		logger.Warn("[quic-host] dial target failed", "target", target, "err", err)
		quicConn.Close()
		return
	}

	if tc, ok := tcp.(*net.TCPConn); ok {
		_ = tc.SetNoDelay(true)
		_ = tc.SetWriteBuffer(tcpSockBufSize)
		_ = tc.SetReadBuffer(tcpSockBufSize)
	}

	logger.Info("[quic-host] stream bridged", "remote", remote, "target", target)
	joinConnGeneric(quicConn, tcp)
}