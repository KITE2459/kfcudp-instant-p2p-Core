package quicbridge

import (
	"context"
	"fmt"
	"log/slog"
	"net"
	"strings"

	"github.com/quic-go/quic-go"
)

func resolveSRV(addr string) string {
	if strings.Contains(addr, ":") {
		return addr
	}
	_, srvs, err := net.LookupSRV("minecraft", "tcp", addr)
	if err == nil && len(srvs) > 0 {
		host := strings.TrimSuffix(srvs[0].Target, ".")
		port := srvs[0].Port
		return fmt.Sprintf("%s:%d", host, port)
	}
	return addr + ":25565"
}

func Join(ctx context.Context, listenAddr, serverAddr string, logger *slog.Logger) error {
	serverAddr = resolveSRV(serverAddr)
	logger.Info("[quic-join] resolved server address", "addr", serverAddr)

	ln, err := net.Listen("tcp", listenAddr)
	if err != nil {
		return fmt.Errorf("local listen: %w", err)
	}
	defer ln.Close()

	logger.Info("[quic-join] listening", "listen", listenAddr, "server", serverAddr)
	fmt.Println("WEBRTC_READY")
	fmt.Printf("QUIC Join: listen=%s server=%s\n", listenAddr, serverAddr)

	for {
		local, err := ln.Accept()
		if err != nil {
			if ctx.Err() != nil {
				return nil
			}
			logger.Warn("[quic-join] accept failed", "err", err)
			return err
		}
		go handleLocalWithOwnConn(ctx, local, serverAddr, logger)
	}
}

func handleLocalWithOwnConn(ctx context.Context, local net.Conn, serverAddr string, logger *slog.Logger) {
	defer local.Close()

	if tc, ok := local.(*net.TCPConn); ok {
		_ = tc.SetNoDelay(true)
		_ = tc.SetWriteBuffer(tcpSockBufSize)
		_ = tc.SetReadBuffer(tcpSockBufSize)
	}

	conn, err := quic.DialAddr(ctx, serverAddr, ClientTLSConfig(), quicClientConfig)
	if err != nil {
		logger.Warn("[quic-join] QUIC dial failed", "err", err)
		return
	}
	defer conn.CloseWithError(0, "bye")

	stream, err := conn.OpenStreamSync(ctx)
	if err != nil {
		logger.Warn("[quic-join] open stream failed", "err", err)
		return
	}

	logger.Info("[quic-join] connected", "remote", local.RemoteAddr())
	quicConn := wrapQuicStream(stream, conn)
	joinConnGeneric(quicConn, local)
}